we were unable to get the code for part two to finish.
it is in the work in progess c file and includes comments with
what we were trying to achive. 

the stats for the report or in the stats folder.